@echo off
REM Whiteboard one-click installer - adds Start Menu + Desktop shortcuts (no admin needed).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause
