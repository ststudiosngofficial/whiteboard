# Whiteboard uninstaller - removes shortcuts + registry, keeps your files.
# Your drawings are autosaved in the browser storage, not deleted.
Remove-Item (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Whiteboard.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) 'Whiteboard.lnk') -Force -ErrorAction SilentlyContinue
# Legacy / OneDrive desktops can differ - clean both so no blank orphan remains.
Remove-Item (Join-Path $env:USERPROFILE 'Desktop\Whiteboard.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $env:USERPROFILE 'OneDrive\Desktop\Whiteboard.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Whiteboard.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Whiteboard' -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item 'HKCU:\Software\Classes\whiteboard' -Recurse -Force -ErrorAction SilentlyContinue
# Also let the exe clean up its own keys/shortcuts
$exe = Join-Path $PSScriptRoot 'Whiteboard.exe'
if (Test-Path $exe) { & $exe --uninstall }
Write-Output 'Whiteboard uninstalled (app files were not deleted - delete this folder to remove them fully).'
