WHITEBOARD 1.1.2 - offline drawing app for Windows
================================================

PRICE: N1,000 one-time per PC (no free trial - view freely, pay to draw)
----------------------------------------------------------
1. Install and open Whiteboard - look around all you like.
2. The moment you touch the board to draw, it asks for payment.
   To unlock forever: click "Buy code - N1,000", pay, then send your
   Product ID (shown in the app) to the seller.
3. The seller sends back your activation code - copy it and paste it
   into the app. Done.

QUICK START (portable, no install needed)
1. Extract this ZIP anywhere (e.g. Documents\Whiteboard)
2. Double-click Whiteboard.exe
3. Optional: double-click Install-Whiteboard.bat to add
   Start Menu + Desktop shortcuts and an Apps entry.

REQUIREMENTS
- Windows 10/11 64-bit (internet needed once if WebView2 is missing)
- Microsoft Edge WebView2 Runtime (preinstalled on most Windows 10/11 PCs).
  If missing, Install-Whiteboard.bat installs it automatically, or the app
  itself offers to install Microsoft's official setup on first launch.

FILES
Whiteboard.exe ........................ main app (double-click to run,
                                  board is built inside - no other file needed)
whiteboard-icon.ico ................... app icon
Microsoft.Web.WebView2.*.dll .......... browser engine bindings
WebView2Loader.dll .................... browser engine loader
WebView2-Bootstrapper.exe ............. official Microsoft WebView2 setup,
                                  runs automatically if the runtime is missing
install.ps1 ........................... creates shortcuts (per-user, no admin)
uninstall.ps1 ......................... removes shortcuts

UNINSTALL
Run uninstall.ps1, then delete this folder.
Your activation is kept, so reinstalling on the same PC stays unlocked.

TIPS
- Double-click empty space = sticky note
- Scroll/pinch = zoom, middle-drag or Space-drag = pan
- Ctrl+S saves a .wbd file, Ctrl+O opens it, PNG button exports an image
- Your work autosaves locally on your PC.

Publisher: Whiteboard 1.1.2 | Buy activation: https://selar.com/1171787jb0
