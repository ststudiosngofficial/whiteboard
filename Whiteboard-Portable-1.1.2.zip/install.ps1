# Whiteboard installer - works on any PC, no admin required.
# Run: right-click > Run with PowerShell, or: powershell -ExecutionPolicy Bypass -File install.ps1
$ErrorActionPreference = 'SilentlyContinue'
$app = $PSScriptRoot
if (-not $app) { $app = Split-Path -Parent $MyInvocation.MyCommand.Path }
$exe = Join-Path $app 'Whiteboard.exe'
$ico = Join-Path $app 'whiteboard-icon.ico'

if (-not (Test-Path $exe)) { Write-Error "Whiteboard.exe not found in $app"; exit 1 }
if (-not (Test-Path $ico)) { $ico = $exe }

# 1. Shortcuts (Start Menu + Desktop) via the app itself (portable paths)
& $exe --install

# 2. Ensure Start Menu shortcut exists even if exe shortcut step was skipped
$ws = New-Object -ComObject WScript.Shell
$lnkPath = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Whiteboard.lnk'
if (-not (Test-Path $lnkPath)) {
  $sc = $ws.CreateShortcut($lnkPath)
  $sc.TargetPath = $exe
  $sc.WorkingDirectory = $app
  $sc.IconLocation = "$ico,0"
  $sc.Description = 'Whiteboard - offline drawing app'
  $sc.Save()
}
Write-Output "SHORTCUT: $lnkPath"

$desktop = Join-Path ([Environment]::GetFolderPath('DesktopDirectory')) 'Whiteboard.lnk'
if (-not (Test-Path $desktop)) {
  $sc2 = $ws.CreateShortcut($desktop)
  $sc2.TargetPath = $exe
  $sc2.WorkingDirectory = $app
  $sc2.IconLocation = "$ico,0"
  $sc2.Description = 'Whiteboard - offline drawing app'
  $sc2.Save()
}
Write-Output "DESKTOP: $desktop"

# 3. Add/Remove Programs entry (per-user, no admin)
$reg = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Whiteboard'
New-Item -Path $reg -Force | Out-Null
Set-ItemProperty -Path $reg -Name 'DisplayName' -Value 'Whiteboard'
Set-ItemProperty -Path $reg -Name 'DisplayIcon' -Value "$ico,0"
Set-ItemProperty -Path $reg -Name 'Publisher' -Value 'Whiteboard'
Set-ItemProperty -Path $reg -Name 'DisplayVersion' -Value '1.1.2'
Set-ItemProperty -Path $reg -Name 'InstallLocation' -Value $app
Set-ItemProperty -Path $reg -Name 'UninstallString' -Value "`"$exe`" --uninstall"
Set-ItemProperty -Path $reg -Name 'NoModify' -Value 1 -Type DWord
Set-ItemProperty -Path $reg -Name 'NoRepair' -Value 1 -Type DWord
Write-Output "APPS ENTRY: $reg"

# 4. WebView2 check (required by Whiteboard.exe).
# NOTE: the runtime lives in a versioned subfolder, e.g. ...\Application\154.x\msedgewebview2.exe,
# and its version is under ...\EdgeUpdate\Clients\{F3017226...} (not ClientState).
function Test-WebView2 {
  foreach ($key in @('HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
                     'HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
                     'HKCU:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}')) {
    $v = (Get-ItemProperty $key -ErrorAction SilentlyContinue).pv
    if ($v) { return $true }
  }
  foreach ($base in @("${env:ProgramFiles(x86)}\Microsoft\EdgeWebView\Application", "$env:ProgramFiles\Microsoft\EdgeWebView\Application")) {
    if (Get-ChildItem "$base\*\msedgewebview2.exe" -ErrorAction SilentlyContinue | Select-Object -First 1) { return $true }
  }
  return $false
}
$wvFound = Test-WebView2
if (-not $wvFound) {
  $boot = Join-Path $app 'WebView2-Bootstrapper.exe'
  if (Test-Path $boot) {
    Write-Output "WebView2 runtime not found - installing now (one-time, needs internet, may ask for permission)..."
    Start-Process -FilePath $boot -ArgumentList "/silent","/install" -Wait
    Start-Sleep -Seconds 3
    $wvFound = Test-WebView2
  }
}
if (-not $wvFound) {
  Write-Warning "Microsoft Edge WebView2 Runtime is still missing. Install it free from https://developer.microsoft.com/microsoft-edge/webview2/ (or re-run this installer with internet on)."
} else {
  Write-Output "WebView2 runtime: ready"
}

Write-Output ""
Write-Output "Done! Launch Whiteboard from the Start Menu or by double-clicking Whiteboard.exe."
